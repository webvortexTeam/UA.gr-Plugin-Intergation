<?php
header('Content-Type: application/json');

$endpoint = "activity";
$api_host = "https://api-staging.unlimited-adrenaline.gr/api/";
$whitelabelid = "6";
$api_locale = "gr";
$api_key = "1340WECHC8CUVAHEXDAAWW7IKXKTSQFVAFYX";
$url = $api_host . $endpoint . '?whiteLabelId=' . urlencode($whitelabelid);

$args_headers = array(
    'Accept: application/json',
    'Content-Type: application/json',
    'apiKey: ' . $api_key,
    'Accept-Language: ' . $api_locale
);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $args_headers);

$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo json_encode(array('error' => "Something went wrong: " . curl_error($ch)));
} else {
    // Decode the JSON response to an associative array
    $response_data = json_decode($response, true);

    // Return the response data as JSON
    echo json_encode($response_data);
}

curl_close($ch);
?>
